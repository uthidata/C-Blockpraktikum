#ifndef NAME_AGE_HPP
#define NAME_AGE_HPP

#include <string>

std::string readName();
uint8_t readAge();

#endif // NAME_AGE_HPP
